% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 1                                                              %
%                                                                           %
%                                                                           %
% This simple phosphorylation-desphosphorylation model is based a lectures  %
%    during the Leizpig Summer Graduate School in June 2023                 %
%                                                                           %
% RESULT: The mass action system has 6 ordinary differential equations.     %
%                                                                           %
% Reference: SLMSI-MPI Leipzig Summer Graduate School on Algebraic          %
%    Methods for Biochemical Reaction Networks (12-23 June 2023)            %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

model.id = 'Example 1';
model = addReaction(model, 'A+E<->AE', ...                 % just a visual guide on how the reaction looks like
                           {'A', 'E'}, {2, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           {'AE'}, {1}, [1], ...           % product species, stoichiometry, "kinetic order" (if reversible)
                           true);                          % reversible or not
model = addReaction(model, 'AE->B+E', ...
                           {'AE'}, {1}, [1], ...
                           {'B', 'E'}, {1, 1}, [1, 1], ...
                           false);
model = addReaction(model, 'B+F<->BF', ...
                           {'B', 'F'}, {1, 1}, [1, 1], ...
                           {'BF'}, {1}, [1], ...
                           true);
model = addReaction(model, 'BF->A+F', ...
                           {'BF'}, {1}, [1], ...
                           {'A', 'F'}, {1, 1}, [1, 1], ...
                           false);

% Generate the mass action system
[N, reactant_complexes, x_dot, ode, model] = CRNtoMAS(model);